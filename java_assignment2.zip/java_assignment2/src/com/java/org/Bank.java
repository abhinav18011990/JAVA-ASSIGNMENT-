package com.java.org;

public class Bank {
	int fd;
	int credit;
	int total = 200000;

	public static void main(String[] args) {

		Bank b = new Bank();
		saving s = new saving();
		current c = new current();

		s.totalcash(200000, 0);
		c.totalcash(0, 300000);

	}

	public void toatlcash() {
		int t = total + fd + credit;
	}

	void totalcash(int fd, int credit) {

		int t = total + fd + credit;

	}

}

class saving extends Bank {

	void totalcash(int fixdepo, int credit) {

		int t = total + fixdepo + credit;

		System.out.println("the saving account total cash" + t);

	}

}

class current extends Bank{
        
        void totalcash(int fd,int credit)
        {
            
            int t=total+fd+credit;
            System.out.println("the current account total cash"+t);
        }

}