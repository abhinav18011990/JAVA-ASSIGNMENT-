package com.java.org;
import java.util.Scanner;
public class Amrstrong {

int x=0;
int y=i;
int z=0;
		
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int i=sc.nextInt();
		
		
		
		while(i!=0) {
			
			
			x=i%10;
			z=z+(x*x*x);
			
			i=i/10;
			
			
			
			
		}
		
		if(z==y)
		{
			System.out.println("The given number is amstrong number");
			
		}
		else
		{
			System.out.println("The given number is  not amstrong number");
			
		}
		

	}

}
