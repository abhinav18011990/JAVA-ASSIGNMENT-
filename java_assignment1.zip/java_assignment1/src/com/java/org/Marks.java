package com.java.org;
import java.util.Scanner;
public class Marks {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Marks of sub1");
		int x=sc.nextInt();
		System.out.println("Enter the Marks of sub2");
		int y=sc.nextInt();
		System.out.println("Enter the Marks of sub3");
		int z=sc.nextInt();
		
		
		if(m1>60&&m2>60&&m3>60)
		{
			
			System.out.println("the student is passed");
			
			
		}
		else if ((x>60 && y>60 && z<60)||(x>60 && y<60 && z>60)||(x<60 && y>60 && z>60) )
		{
			
			
			System.out.println("the student is promoted");
				
			
			
		}
		else 
		{
			
			
			System.out.println("the student is failed");
			
		}
		
		

	}

}
