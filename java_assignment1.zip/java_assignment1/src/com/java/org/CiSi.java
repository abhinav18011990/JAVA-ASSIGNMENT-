package com.java.org;
import java.util.Scanner;
public class CiSi {
	
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Principal amount");
		double p=sc.nextDouble();
		System.out.println("Enter the rate of interest");
		double r=sc.nextDouble();
		System.out.println("Enter the time interval");
		double t=sc.nextDouble();
		System.out.println("Enter number of times interest is compounded");
		double n=sc.nextDouble();
		
		double si= ((p*r*t)/100);
		double ci= p*(Math.pow((1+r/100),(t*n))-p;
		
		
		
		System.out.println("the simple intrest is"+si);
		System.out.println("the compund intrest is"+ci);
	

	}

}
